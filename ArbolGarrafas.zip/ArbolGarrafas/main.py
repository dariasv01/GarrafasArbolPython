import ArbolGarrafas as ar


def check(estado, historico, nodos):
    if estado not in historico and estado not in nodos:
        return True
    else:
        return False


def transpasar(garrafaUno, garrafaDos, valorOldUno, valorOldDos):
    if (garrafaUno.capacidad < garrafaUno.maxCap and garrafaDos.capacidad > 0):
        res = valorOldUno + valorOldDos
        if res >= garrafaUno.maxCap:
            if valorOldDos > valorOldUno:
                garrafaUno.llenar()
                garrafaDos.setCapacidad(res - garrafaUno.maxCap)
            elif (valorOldDos == valorOldUno):
                garrafaUno.llenar()
                garrafaDos.setCapacidad(res - garrafaUno.maxCap)
            else:
                garrafaUno.llenar()
                garrafaDos.setCapacidad(valorOldUno - valorOldDos)
        else:
            garrafaUno.setCapacidad(res)
            garrafaDos.setCapacidad(0)

    return [garrafaUno.getCapacidad(), garrafaDos.getCapacidad()]


a = ar.Garrafa(0, 5)
b = ar.Garrafa(0, 3)

arbol = ar.ArbolGarrafas([a.capacidad, b.capacidad])
historico = []
nodos = [[a.capacidad, b.capacidad]]

while (a.getCapacidad() + b.getCapacidad() != 7) and len(nodos) > 0:
    g5 = nodos[0][0]
    g3 = nodos[0][1]
    a.setCapacidad(nodos[0][0])
    b.setCapacidad(nodos[0][1])
    print(nodos)

    if a.capacidad != 0:
        a.vaciar()
        if check([a.getCapacidad(), b.getCapacidad()], historico, nodos):
            nodos.append([a.capacidad, b.capacidad])
        a.capacidad = g5
        b.capacidad = g3
    if b.capacidad != 0:
        b.vaciar()
        if check([a.getCapacidad(), b.getCapacidad()], historico, nodos):
            nodos.append([a.capacidad, b.capacidad])
        a.capacidad = g5
        b.capacidad = g3
    if a.capacidad != 0 and b.capacidad < b.maxCap:
        result = transpasar(b, a, b.capacidad, a.capacidad)
        a.setCapacidad(result[0])
        b.setCapacidad(result[1])
        if check([a.getCapacidad(), b.getCapacidad()], historico, nodos):
            nodos.append([a.capacidad, b.capacidad])
        a.capacidad = g5
        b.capacidad = g3
    if b.capacidad != 0 and a.capacidad < a.maxCap:
        result = transpasar(a, b, a.capacidad, b.capacidad)
        b.setCapacidad(result[0])
        a.setCapacidad(result[1])
        if check([a.getCapacidad(), b.getCapacidad()], historico, nodos):
            nodos.append([a.capacidad, b.capacidad])
        a.capacidad = g5
        b.capacidad = g3
    if a.capacidad == 0:
        a.llenar()
        if check([a.getCapacidad(), b.getCapacidad()], historico, nodos):
            nodos.append([a.capacidad, b.capacidad])
        a.capacidad = g5
        b.capacidad = g3
    if b.capacidad == 0:
        b.llenar()
        if check([a.getCapacidad(), b.getCapacidad()], historico, nodos):
            nodos.append([a.capacidad, b.capacidad])
        a.capacidad = g5
        b.capacidad = g3
    historico.append([g5, g3])
    nodos.pop(0)

print(historico)
