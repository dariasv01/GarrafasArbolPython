class Garrafa:

    def __init__(self, capacidad, maxCap):
        self.capacidad = capacidad
        self.maxCap = maxCap

    def llenar(self):
        self.capacidad = self.maxCap

    def vaciar(self):
        self.capacidad = 0

    def getCapacidad(self):
        return self.capacidad

    def setCapacidad(self, cap):
        self.capacidad = cap

    def getMaxCap(self):
        return self.maxCap


class ArbolGarrafas:

    def __init__(self,estado):
        self.estado = estado
        self.hijos = []


    def getEstado(self):
        return self.estado

    def setEstado(self, estado):
        self.estado = estado

    def getHijos(self):
        return self.hijos

    def setHijos(self, hijos):
        self.hijos = hijos

    def mostrar(self):
        print(self.estado)
        if len(self.getHijos()) > 0:
            for i in self.getHijos():
                i.mostrar()
